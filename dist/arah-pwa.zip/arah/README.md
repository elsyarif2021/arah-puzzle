# Arah

Puzzle panah PWA dengan 10 level dalam kategori Mudah, Sedang, dan Sulit. Ketuk panah yang jalurnya bebas. Percobaan yang terhalang mengurangi satu nyawa. Jawab soal Juz 29 atau 30 untuk menyingkirkan penghalang atau memakai petunjuk. Selesaikan minimal satu soal untuk membuka panah terakhir pada papan baru. Setiap soal menampilkan rujukan dan terjemahan Quran.ai edisi id-id, bersumber dari Quran.com edisi 33.

Tombol suara mengatur playback Alhamdulillah dan Astaghfirullah. Kuis dan audio tersimpan di cache offline setelah pemuatan awal. Tantangan harian menggunakan tanggal WIB. Progres disimpan di browser, dan papan lama tetap dapat diteruskan hingga pemain menekan Ulangi.

## Jalankan

Ekstrak arsip, buka terminal di folder ini, lalu jalankan `python3 -m http.server 8765`. Buka http://localhost:8765 dan tunggu teks “Siap dimainkan offline”. Untuk mengaksesnya dari HP, hos seluruh isi folder di hosting statis HTTPS. Tombol “Pasang aplikasi” menampilkan petunjuk pemasangan.

Tidak ada dependensi runtime.
