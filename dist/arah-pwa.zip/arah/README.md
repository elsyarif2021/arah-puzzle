# Arah

PWA puzzle panah dengan 10 level, tiga nyawa, dan satu petunjuk per percobaan. Ketuk garis yang jalurnya bebas hingga semua panah keluar. Level dan permainan aktif tersimpan di browser. Tantangan harian menggunakan tanggal WIB dan papan yang sama untuk setiap pemain pada tanggal tersebut. Unduh ulang atau ganti perangkat akan memulai progres terpisah jika penyimpanan browser tidak ikut dipindah.

## Jalankan

Ekstrak arsip, buka terminal di folder ini, lalu jalankan `python3 -m http.server 8000`. Buka http://localhost:8000 dan tunggu teks “Siap dimainkan offline”. Untuk HP, hos seluruh isi folder di hosting statis HTTPS. Gunakan tombol “Pasang aplikasi” untuk melihat cara pemasangan pada perangkatmu. Mode offline berfungsi setelah cache awal selesai. Firefox dan beberapa browser mendukung gameplay offline tanpa menawarkan pemasangan aplikasi.

Tidak ada dependensi runtime, akun, leaderboard, atau transaksi uang.
